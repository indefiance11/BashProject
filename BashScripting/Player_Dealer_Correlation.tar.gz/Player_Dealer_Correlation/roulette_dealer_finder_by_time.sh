#!/bin/bash

dealer=$(cat $1_Dealer_schedule  | grep -E "$2.*$3" | awk '{print $1, $2, $5, $6}')

echo $dealer
